# STAG Camera 15T Pro v2

ฟังก์ชัน: ภาพนิ่ง, Night Extension ของ OEM, วิดีโอ UHD พร้อมร้องขอ 60fps, เสียง, ซูม 1x/5x/10x/20x, pinch zoom และ automatic lens switching ผ่าน logical rear camera/HAL

ข้อจำกัด: 4K60, NIGHT และการสลับไปเลนส์กายภาพ 5x ต้องได้รับการเปิดเผยโดย Xiaomi Camera HAL ต่อแอปภายนอก แอปมี fallback เมื่อ combination ไม่รองรับ และไม่สามารถรับประกัน Leica/Ultra Zoom pipeline เท่ากับแอประบบได้

Build ด้วย Android Studio หรือ GitHub Actions ใน `.github/workflows/build-apk.yml`.

## v8.2 Build-ready review
ดู `BUILD_READY_v8_2.md` สำหรับผลตรวจ source และข้อจำกัดที่ต้องทดสอบบน Xiaomi 15T Pro จริง
