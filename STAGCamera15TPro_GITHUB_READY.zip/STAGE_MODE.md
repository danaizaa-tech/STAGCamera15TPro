# STAGE Mode for Xiaomi 15T Pro

Inspired by the public feature set of Xiaomi 17T Pro, implemented using public Android camera APIs.

## Options
- AUTO: 5x tele priority, EV -1
- PERSON: 5x, face-priority intent, EV -2 for skin/highlight balance
- LIGHT: 5x, EV -3 to protect spotlights and LED screens
- VIDEO: UHD/4K 60 fps request with tele priority
- Works with 1x/5x/10x/20x zoom buttons and logical-camera auto switching
- CLASSIC/VIVID/NATURAL tone selectors remain available

## Differences from Xiaomi 17T Pro OEM Stage Mode
The 15T Pro app cannot bundle Xiaomi 17T Pro's private subject-segmentation model, AI Ultra Zoom reconstruction, Leica proprietary look tables, or hidden HAL commands. STAG uses exposure control, zoom selection, OEM HDR/Night extensions, CameraX capture and capability fallbacks.
