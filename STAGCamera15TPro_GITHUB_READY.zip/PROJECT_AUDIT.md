# Project Audit: STAG Camera v5.1

## Checks passed
- ZIP integrity and expected Android project structure
- AndroidManifest and all resource XML files are well formed
- Kotlin delimiter sanity check: braces and parentheses balanced
- Required camera/audio permissions present
- CameraX preview, image capture, video capture, extensions, and ML Kit dependencies declared
- GitHub Actions build workflow present

## Corrections made
- Added ExperimentalGetImage opt-in required for ImageProxy.image access
- Throttled AF/AE retargeting to once per 1.2 seconds to reduce focus hunting
- Throttled automatic EV changes to once per 700 ms to reduce exposure pumping
- Corrected misleading tone labels: Natural/Classic/Vivid are UI presets only until a real CameraEffect/SurfaceProcessor is implemented
- Corrected saved-photo message so it does not claim an unapplied tone
- Added application backup and RTL metadata

## Known unresolved items requiring a real Android build/device
- No Gradle wrapper is bundled; GitHub Actions provisions Gradle 8.9, while local Android Studio can use its Gradle environment
- 4K60 request is not proof the encoded file is 60 fps; verify output metadata on Xiaomi 15T Pro
- Face-box coordinate mapping does not yet fully account for PreviewView crop/rotation/mirroring
- Stage tracking is enabled for still-photo Stage mode, not guaranteed simultaneously with 4K60
- Natural/Classic/Vivid image processing is not implemented
- Logical-camera physical lens switching depends on Xiaomi Camera HAL

## Build status
Static validation passed. Full compilation was not executed in this environment because Android SDK/Build Tools are unavailable.


## v5.2 corrections
- NATURAL/CLASSIC/VIVID now process captured JPEG pixels before MediaStore save.
- CLASSIC uses a warm, restrained matrix; VIVID uses a stronger RGB matrix plus saturation. These are original STAG looks, not Leica profiles.
- Face rectangles now use ImageProxyTransformFactory + CoordinateTransform into PreviewView output coordinates, accounting for rotation, CropRect and PreviewView transformation.
