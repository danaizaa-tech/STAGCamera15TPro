# Custom Stage Mode v7

A separate CUSTOM menu is available inside Concert Hub.

Controls:
- Zoom: 1.0x to 20.0x in 0.1x steps, clamped by Camera HAL
- Exposure compensation: EV index -4 to +4, clamped by the device exposure range
- Tone: cycles NATURAL, CLASSIC, VIVID and affects saved still JPEG
- Performer tracking: ON/OFF
- Highlight Guard: ON/OFF
- APPLY: applies current settings
- SAVE: applies and persists settings with SharedPreferences
- CLOSE: hides the custom panel

Saved settings are loaded the next time CUSTOM is opened.
