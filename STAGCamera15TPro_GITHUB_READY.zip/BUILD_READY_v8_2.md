# STAG Camera 15T Pro v8.2 — Build Ready Notes

## ตรวจและแก้แล้ว
- ตรวจ `MainActivity.kt` แบบ static source review
- ยืนยัน `ActivityMainBinding` มาจาก Android View Binding และไม่ใช่ missing XML ID
- ยืนยัน `::binding.isInitialized` เป็น Kotlin property initialization check และไม่ใช่ XML ID
- ตรวจสมดุลวงเล็บ Kotlin: ผ่าน
- ตรวจ binding references กับ `activity_main.xml`: 41/41 UI references ตรงกับ XML (ไม่นับ generated binding class และ `isInitialized`)
- ปรับข้อความสถานะตอนเริ่มบันทึกวิดีโอ ไม่ให้ยืนยันว่าเป็น 4K/60 โดยไม่มีหลักฐานจาก Recorder/HAL
- เก็บตัวแปร `selectedVideoQuality` เพื่อให้ status ตรงกับ Quality ที่เลือกจริง

## สิ่งที่ยังต้องทดสอบบนเครื่อง/CI
- Android Gradle Plugin / dependency resolution
- Camera HAL ของ Xiaomi 15T Pro
- 4K60 จริงจากไฟล์ MP4 ที่บันทึกได้
- การเลือก physical tele lens ที่ 5x
- Night/HDR Extension availability
- Face overlay alignment ใน crop/zoom ต่าง ๆ

## Build
โปรเจกต์มี GitHub Actions workflow ที่ติดตั้ง Gradle 8.9 และ Android SDK 35 แล้ว จึงสามารถ build ได้โดยไม่ต้องมี Gradle Wrapper ใน ZIP นี้

คำสั่งบนเครื่องที่มี Gradle 8.9:
`gradle :app:assembleDebug`

ผลลัพธ์:
`app/build/outputs/apk/debug/app-debug.apk`
