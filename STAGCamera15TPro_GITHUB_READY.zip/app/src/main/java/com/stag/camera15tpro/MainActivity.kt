package com.stag.camera15tpro

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.provider.MediaStore
import android.util.Range
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Toast
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.*
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import com.stag.camera15tpro.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import android.graphics.RectF
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.view.transform.CoordinateTransform
import androidx.camera.view.transform.ImageProxyTransformFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors
import java.io.OutputStream
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var capture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var selectedVideoQuality: Quality = Quality.FHD
    private var recording: Recording? = null
    private var cameraReleased=true
    private var activityStopping=false
    private var lastModeBeforeStop=Mode.PHOTO
    private val analysisExecutor=Executors.newSingleThreadExecutor()
    private val analyzing=AtomicBoolean(false)
    private var highlightGuard=true
    private var concertPreset="SMART"
    private var audioFocusMode=false
    private var customZoomRatio=5f
    private var customEvIndex=-2
    private var customTracking=true
    private var customToneIndex=0
    private var trackedId:Int?=null
    private var lastEv=0
    private var lastFocusAt=0L
    private var lastHighlightChangeAt=0L
    private val faceDetector=FaceDetection.getClient(FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .enableTracking().setMinFaceSize(0.08f).build())
    private var mode = Mode.PHOTO
    private var tone = Tone.NATURAL
    private enum class Mode { PHOTO, NIGHT, HDR, VIDEO, STAGE }
    private enum class Tone { NATURAL, CLASSIC, VIVID }

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) startProvider() else toast("ต้องอนุญาตการใช้กล้อง")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater); setContentView(binding.root)
        permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        mapOf(binding.z1 to 1f, binding.z5 to 5f, binding.z10 to 10f, binding.z20 to 20f).forEach { (b,z) -> b.setOnClickListener { setZoom(z) } }
        binding.photoMode.setOnClickListener { mode=Mode.PHOTO; hideStage(); bindPhoto(false) }
        binding.nightMode.setOnClickListener { mode=Mode.NIGHT; hideStage(); bindPhoto(true) }
        binding.videoMode.setOnClickListener { mode=Mode.VIDEO; hideStage(); bindVideo4K60() }
        binding.hdrMode.setOnClickListener { mode=Mode.HDR; hideStage(); bindExtension(ExtensionMode.HDR, "HDR OEM • รวมช่วงแสง") }
        binding.stageMode.setOnClickListener { enterStage() }
        binding.stageAuto.setOnClickListener { applyConcertPreset("SMART",-1,5f,Tone.NATURAL,true) }
        binding.stagePerson.setOnClickListener { applyConcertPreset("PERFORMER",-2,5f,Tone.CLASSIC,true) }
        binding.stageLight.setOnClickListener { applyConcertPreset("SPOTLIGHT",-3,5f,Tone.NATURAL,true) }
        binding.stageZoom.setOnClickListener { applyConcertPreset("FAR ZOOM",-2,10f,Tone.CLASSIC,true) }
        binding.stageMotion.setOnClickListener { applyConcertPreset("MOTION",-1,5f,Tone.VIVID,true) }
        binding.stageNight.setOnClickListener { concertPreset="NIGHT"; mode=Mode.NIGHT; bindPhoto(true) }
        binding.stageColor.setOnClickListener { applyConcertPreset("TRUE COLOR",-1,5f,Tone.NATURAL,true) }
        binding.stageAudio.setOnClickListener { audioFocusMode=!audioFocusMode; binding.status.text=if(audioFocusMode) "AUDIO FOCUS • ลด gain ป้องกันเสียงแตก" else "AUDIO NORMAL" }
        binding.stageCustom.setOnClickListener { openCustomStage() }
        binding.customZoom.setOnSeekBarChangeListener(simpleSeek { progress ->
            customZoomRatio=1f+progress/10f; binding.customZoomLabel.text="Zoom %.1f×".format(customZoomRatio)
        })
        binding.customEv.setOnSeekBarChangeListener(simpleSeek { progress ->
            customEvIndex=progress-4; binding.customEvLabel.text="EV ${if(customEvIndex>0) "+" else ""}$customEvIndex"
        })
        binding.customTone.setOnClickListener { cycleCustomTone() }
        binding.customTracking.setOnClickListener { customTracking=!customTracking; binding.customTracking.text=if(customTracking) "TRACK ON" else "TRACK OFF" }
        binding.customHighlight.setOnClickListener { highlightGuard=!highlightGuard; binding.customHighlight.text=if(highlightGuard) "HIGHLIGHT ON" else "HIGHLIGHT OFF" }
        binding.customApply.setOnClickListener { applyCustomStage(false) }
        binding.customSave.setOnClickListener { applyCustomStage(true) }
        binding.customClose.setOnClickListener { binding.customStagePanel.visibility=View.GONE }
        binding.stageVideo.setOnClickListener { mode=Mode.VIDEO; bindVideo4K60(); binding.status.text="CONCERT VIDEO • 4K60 request • Tele priority • Audio ${if(audioFocusMode) "Focus" else "Normal"}" }
        binding.toneNatural.setOnClickListener { tone=Tone.NATURAL; binding.status.text="Tone: Natural • processing active" }
        binding.toneClassic.setOnClickListener { tone=Tone.CLASSIC; binding.status.text="Tone: Classic • processing active" }
        binding.toneVivid.setOnClickListener { tone=Tone.VIVID; binding.status.text="Tone: Vivid • processing active" }
        binding.shutter.setOnClickListener { if (mode==Mode.VIDEO) toggleVideo() else takePhoto() }
        val detector=ScaleGestureDetector(this, object:ScaleGestureDetector.SimpleOnScaleGestureListener(){
            override fun onScale(d:ScaleGestureDetector):Boolean { camera?.cameraInfo?.zoomState?.value?.let { setZoom(it.zoomRatio*d.scaleFactor) }; return true }
        })
        binding.preview.setOnTouchListener { _,e -> detector.onTouchEvent(e); true }
    }

    private fun startProvider() {
        if(isFinishing || isDestroyed) return
        val f=ProcessCameraProvider.getInstance(this)
        f.addListener({
            if(isFinishing || isDestroyed) return@addListener
            provider=f.get(); cameraReleased=false
            restoreCameraMode()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun restoreCameraMode(){
        when(lastModeBeforeStop){
            Mode.VIDEO -> { mode=Mode.VIDEO; bindVideo4K60() }
            Mode.NIGHT -> { mode=Mode.NIGHT; bindPhoto(true) }
            Mode.HDR -> { mode=Mode.HDR; bindExtension(ExtensionMode.HDR,"HDR OEM • รวมช่วงแสง") }
            Mode.STAGE -> { mode=Mode.STAGE; bindPhotoWithSelector(CameraSelector.DEFAULT_BACK_CAMERA,"CONCERT $concertPreset") }
            else -> { mode=Mode.PHOTO; bindPhoto(false) }
        }
    }

    private fun previewBuilder60(): Preview.Builder {
        val builder=Preview.Builder().setTargetFrameRate(Range(60,60))
        Camera2Interop.Extender(builder).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(60,60))
        return builder
    }

    private fun bindPhoto(night:Boolean) {
        if (!night) { bindPhotoWithSelector(CameraSelector.DEFAULT_BACK_CAMERA, "PHOTO • สลับเลนส์อัตโนมัติตาม Zoom HAL"); return }
        bindExtension(ExtensionMode.NIGHT, "NIGHT OEM • ประมวลผลหลายเฟรม")
    }

    private fun bindExtension(extension:Int, label:String) {
        val p=provider ?: return
        val base=CameraSelector.DEFAULT_BACK_CAMERA
        val ef=ExtensionsManager.getInstanceAsync(this,p)
        ef.addListener({
            val em=ef.get()
            if(em.isExtensionAvailable(base, extension)) bindPhotoWithSelector(em.getExtensionEnabledCameraSelector(base, extension), label)
            else bindPhotoWithSelector(base, "$label • fallback เพราะ OEM ไม่เปิด API")
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindPhotoWithSelector(selector:CameraSelector,label:String) {
        val p=provider ?: return
        val preview=Preview.Builder().build().also { it.surfaceProvider=binding.preview.surfaceProvider }
        capture=ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
        val analysis=buildStageAnalysis()
        p.unbindAll(); cameraReleased=false; camera=if(mode==Mode.STAGE) p.bindToLifecycle(this,selector,preview,capture,analysis) else p.bindToLifecycle(this,selector,preview,capture)
        videoCapture=null; updateZoom(); binding.status.text="STAG • $label"; binding.shutter.text="●"
    }

    private fun enterStage() {
        mode=Mode.STAGE
        concertPreset="SMART"
        binding.stageBar.visibility=View.VISIBLE
        bindPhotoWithSelector(CameraSelector.DEFAULT_BACK_CAMERA, "CONCERT NIGHT • Person tracking • Highlight Guard")
        setZoom(5f)
        setExposure(-2)
    }

    private fun hideStage(){ binding.stageBar.visibility=View.GONE; binding.customStagePanel.visibility=View.GONE }

    private fun simpleSeek(onChange:(Int)->Unit)=object:SeekBar.OnSeekBarChangeListener{
        override fun onProgressChanged(bar:SeekBar,progress:Int,fromUser:Boolean){if(fromUser)onChange(progress)}
        override fun onStartTrackingTouch(bar:SeekBar){}
        override fun onStopTrackingTouch(bar:SeekBar){}
    }

    private fun openCustomStage(){
        mode=Mode.STAGE; concertPreset="CUSTOM"
        binding.stageBar.visibility=View.VISIBLE;binding.customStagePanel.visibility=View.VISIBLE
        val prefs=getSharedPreferences("stage_custom",MODE_PRIVATE)
        customZoomRatio=prefs.getFloat("zoom",5f);customEvIndex=prefs.getInt("ev",-2)
        customTracking=prefs.getBoolean("tracking",true);highlightGuard=prefs.getBoolean("highlight",true)
        customToneIndex=prefs.getInt("tone",0);tone=Tone.values()[customToneIndex.coerceIn(0,Tone.values().lastIndex)]
        binding.customZoom.progress=((customZoomRatio-1f)*10).toInt().coerceIn(0,190)
        binding.customEv.progress=(customEvIndex+4).coerceIn(0,8)
        binding.customZoomLabel.text="Zoom %.1f×".format(customZoomRatio);binding.customEvLabel.text="EV $customEvIndex"
        binding.customTracking.text=if(customTracking)"TRACK ON" else "TRACK OFF"
        binding.customHighlight.text=if(highlightGuard)"HIGHLIGHT ON" else "HIGHLIGHT OFF"
        binding.customTone.text="TONE ${tone.name.take(3)}"
    }

    private fun cycleCustomTone(){
        customToneIndex=(customToneIndex+1)%Tone.values().size;tone=Tone.values()[customToneIndex]
        binding.customTone.text="TONE ${tone.name.take(3)}"
    }

    private fun applyCustomStage(save:Boolean){
        concertPreset="CUSTOM";mode=Mode.STAGE
        if(save)getSharedPreferences("stage_custom",MODE_PRIVATE).edit()
            .putFloat("zoom",customZoomRatio).putInt("ev",customEvIndex)
            .putBoolean("tracking",customTracking).putBoolean("highlight",highlightGuard)
            .putInt("tone",customToneIndex).apply()
        bindPhotoWithSelector(CameraSelector.DEFAULT_BACK_CAMERA,"CUSTOM STAGE")
        setZoom(customZoomRatio);setExposure(customEvIndex)
        if(!customTracking)binding.faceOverlay.update(null,"")
        binding.status.text="CUSTOM • %.1f× • EV %d • %s • Track %s • Guard %s%s".format(
            customZoomRatio,customEvIndex,tone.name,if(customTracking)"ON" else "OFF",if(highlightGuard)"ON" else "OFF",if(save)" • SAVED" else "")
    }

    private fun applyConcertPreset(name:String, exposure:Int, zoom:Float, selectedTone:Tone, guard:Boolean) {
        concertPreset=name; tone=selectedTone; highlightGuard=guard
        if(mode!=Mode.STAGE){mode=Mode.STAGE;bindPhotoWithSelector(CameraSelector.DEFAULT_BACK_CAMERA,"CONCERT $name")}
        setZoom(zoom);setExposure(exposure)
        binding.status.text="CONCERT $name • ${zoom.toInt()}× • EV $exposure • ${selectedTone.name} • Tracking ON"
    }

    private fun stagePreset(name:String, exposure:Int, zoom:Float) {
        if(mode!=Mode.STAGE) mode=Mode.STAGE
        setZoom(zoom); setExposure(exposure)
        binding.status.text="STAGE $name • ${zoom.toInt()}× • EV $exposure"
    }

    private fun setExposure(index:Int) {
        val range=camera?.cameraInfo?.exposureState?.exposureCompensationRange ?: return
        camera?.cameraControl?.setExposureCompensationIndex(index.coerceIn(range.lower,range.upper))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun buildStageAnalysis():ImageAnalysis {
        return ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build().also { useCase ->
            useCase.setAnalyzer(analysisExecutor) { image ->
                val media=image.image
                if(media==null || !analyzing.compareAndSet(false,true)){image.close();return@setAnalyzer}
                val luma=highlightRatio(image)
                val input=InputImage.fromMediaImage(media,image.imageInfo.rotationDegrees)
                faceDetector.process(input).addOnSuccessListener { faces ->
                    val chosen=if(mode==Mode.STAGE && (!concertPreset.equals("CUSTOM") || customTracking)) faces.maxByOrNull { it.boundingBox.width()*it.boundingBox.height() } else null
                    chosen?.trackingId?.let { trackedId=it }
                    runOnUiThread {
                        if(highlightGuard) applyHighlightGuard(luma)
                        if(chosen!=null) {
                            val mapped=mapFace(chosen.boundingBox,image)
                            binding.faceOverlay.update(mapped,"TRACK ${chosen.trackingId ?: 0} • EV $lastEv")
                            if(mapped!=null) focusOn(mapped.centerX(),mapped.centerY())
                            binding.status.text="CONCERT $concertPreset • Track ${chosen.trackingId ?: 0} • Highlight ${(luma*100).toInt()}% • EV $lastEv"
                        } else binding.faceOverlay.update(null,"")
                    }
                }.addOnCompleteListener { analyzing.set(false);image.close() }
            }
        }
    }

    private fun highlightRatio(image:ImageProxy):Double {
        val b=image.planes[0].buffer.duplicate();var bright=0;var count=0
        val step=16
        while(b.remaining()>0){val v=b.get().toInt() and 255;if(count%step==0 && v>235) bright++;count++}
        return bright.toDouble()/max(1,count/step).toDouble()
    }

    private fun applyHighlightGuard(ratio:Double){
        val target=when { ratio>0.18 -> -4; ratio>0.10 -> -3; ratio>0.05 -> -2; ratio>0.02 -> -1; else -> 0 }
        val now=System.currentTimeMillis()
        if(target!=lastEv && now-lastHighlightChangeAt>700){lastHighlightChangeAt=now;lastEv=target;setExposure(target)}
    }

    private fun mapFace(r:android.graphics.Rect,image:ImageProxy):RectF? {
        val target=binding.preview.outputTransform ?: return null
        val source=ImageProxyTransformFactory().apply {
            isUsingRotationDegrees=true
            isUsingCropRect=true
        }.getOutputTransform(image)
        return RectF(r).also { CoordinateTransform(source,target).mapRect(it) }
    }

    private fun focusOn(x:Float,y:Float){
        val now=System.currentTimeMillis()
        if(now-lastFocusAt<1200) return
        lastFocusAt=now
        val point=binding.preview.meteringPointFactory.createPoint(x,y)
        val action=FocusMeteringAction.Builder(point,FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(3,TimeUnit.SECONDS).build()
        camera?.cameraControl?.startFocusAndMetering(action)
    }

    private fun bindVideo4K60() {
        val p=provider ?: return
        val selector=CameraSelector.DEFAULT_BACK_CAMERA
        val info=p.getCameraInfo(selector)
        val qualities=Recorder.getVideoCapabilities(info).getSupportedQualities()
        val selected=if(qualities.contains(Quality.UHD)) Quality.UHD else Quality.FHD
        selectedVideoQuality=selected
        val recorder=Recorder.Builder().setQualitySelector(QualitySelector.from(selected, FallbackStrategy.higherQualityOrLowerThan(selected))).build()
        videoCapture=VideoCapture.withOutput(recorder)
        val preview=previewBuilder60().build().also { it.surfaceProvider=binding.preview.surfaceProvider }
        capture=null; p.unbindAll(); cameraReleased=false
        try {
            camera=p.bindToLifecycle(this,selector,preview,videoCapture)
            binding.status.text="VIDEO • ${if(selected==Quality.UHD) "4K" else "1080p fallback"} • ขอ 60fps • Auto lens"
        } catch(e:Exception) {
            val safePreview=Preview.Builder().build().also { it.surfaceProvider=binding.preview.surfaceProvider }
            camera=p.bindToLifecycle(this,selector,safePreview,videoCapture)
            binding.status.text="VIDEO • คุณภาพสูงสุดที่ HAL รองรับ • 60fps ไม่พร้อม"
        }
        updateZoom(); binding.shutter.text="REC"
    }

    private fun toggleVideo() {
        recording?.let { it.stop(); recording=null; binding.shutter.text="REC"; return }
        val vc=videoCapture ?: return
        val values=ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME,"STAG_${stamp()}.mp4"); put(MediaStore.Video.Media.MIME_TYPE,"video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/STAG") }
        val out=MediaStoreOutputOptions.Builder(contentResolver,MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        var pending=vc.output.prepareRecording(this,out)
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) pending=pending.withAudioEnabled()
        recording=pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when(event) {
                is VideoRecordEvent.Start -> { binding.shutter.text="STOP"; binding.status.text="กำลังบันทึก ${if (selectedVideoQuality == Quality.UHD) "4K" else "1080p"} • FPS ตาม Recorder/HAL" }
                is VideoRecordEvent.Finalize -> { binding.shutter.text="REC"; recording=null; toast(if(event.hasError()) "วิดีโอผิดพลาด ${event.error}" else "บันทึกใน Movies/STAG แล้ว") }
            }
        }
    }

    private fun setZoom(requested:Float) {
        val z=camera?.cameraInfo?.zoomState?.value ?: return
        val applied=min(max(requested,z.minZoomRatio),z.maxZoomRatio)
        camera?.cameraControl?.setZoomRatio(applied)
        binding.status.text="Zoom %.1f× • Logical camera เลือกเลนส์อัตโนมัติ".format(applied)
    }

    private fun updateZoom() {
        val z=camera?.cameraInfo?.zoomState?.value ?: return
        listOf(binding.z1 to 1f,binding.z5 to 5f,binding.z10 to 10f,binding.z20 to 20f).forEach { (b,r)->b.isEnabled=r<=z.maxZoomRatio;b.alpha=if(b.isEnabled)1f else .35f }
    }

    private fun takePhoto() {
        val ic=capture ?: return
        binding.status.text=if(mode==Mode.NIGHT)"NIGHT • ถือเครื่องให้นิ่ง กำลังประมวลผล" else "กำลังถ่ายและลงโทน ${tone.name}"
        ic.takePicture(analysisExecutor,object:ImageCapture.OnImageCapturedCallback(){
            override fun onCaptureSuccess(image:ImageProxy){
                try {
                    val buffer=image.planes[0].buffer
                    val bytes=ByteArray(buffer.remaining()).also { buffer.get(it) }
                    val decoded=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                        ?: throw IllegalStateException("Decode JPEG failed")
                    val rotated=rotateBitmap(decoded,image.imageInfo.rotationDegrees)
                    val processed=applyTone(rotated,tone)
                    saveProcessedBitmap(processed)
                    if(processed!==rotated) processed.recycle()
                    if(rotated!==decoded) rotated.recycle()
                    decoded.recycle()
                } catch(e:Exception){runOnUiThread{toast("ประมวลผลไม่สำเร็จ: ${e.message}")}}
                finally { image.close() }
            }
            override fun onError(e:ImageCaptureException){runOnUiThread{toast("ถ่ายไม่สำเร็จ: ${e.message}")}}
        })
    }

    private fun rotateBitmap(source:Bitmap,degrees:Int):Bitmap {
        if(degrees%360==0) return source
        return Bitmap.createBitmap(source,0,0,source.width,source.height,Matrix().apply{postRotate(degrees.toFloat())},true)
    }

    private fun applyTone(source:Bitmap,tone:Tone):Bitmap {
        if(tone==Tone.NATURAL) return source.copy(Bitmap.Config.ARGB_8888,false)
        val matrix=when(tone){
            Tone.CLASSIC -> ColorMatrix(floatArrayOf(
                1.05f,-0.02f,-0.03f,0f,-3f,
                -0.03f,1.02f,0.01f,0f,-2f,
                -0.01f,0.03f,0.93f,0f,-4f,
                0f,0f,0f,1f,0f))
            Tone.VIVID -> ColorMatrix(floatArrayOf(
                1.12f,-0.04f,-0.02f,0f,2f,
                -0.03f,1.10f,-0.02f,0f,1f,
                -0.02f,-0.04f,1.14f,0f,2f,
                0f,0f,0f,1f,0f)).apply { postConcat(ColorMatrix().apply{setSaturation(1.18f)}) }
            else -> ColorMatrix()
        }
        val output=Bitmap.createBitmap(source.width,source.height,Bitmap.Config.ARGB_8888)
        Canvas(output).drawBitmap(source,0f,0f,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply{
            colorFilter=ColorMatrixColorFilter(matrix)
        })
        return output
    }

    private fun saveProcessedBitmap(bitmap:Bitmap){
        val values=ContentValues().apply{
            put(MediaStore.Images.Media.DISPLAY_NAME,"STAG_${stamp()}_${tone.name}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/STAG")
        }
        val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)
            ?: throw IllegalStateException("Create MediaStore item failed")
        contentResolver.openOutputStream(uri)?.use { out ->
            if(!bitmap.compress(Bitmap.CompressFormat.JPEG,95,out)) throw IllegalStateException("JPEG encode failed")
        } ?: throw IllegalStateException("Open output failed")
        runOnUiThread{toast("บันทึกภาพโทน ${tone.name} ใน Pictures/STAG แล้ว")}
    }

    override fun onStart(){
        super.onStart()
        if(activityStopping){
            activityStopping=false
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startProvider()
        }
    }

    override fun onStop(){
        lastModeBeforeStop=mode
        activityStopping=true
        releaseCameraResources("แอปอยู่เบื้องหลัง")
        super.onStop()
    }

    private fun releaseCameraResources(reason:String){
        if(cameraReleased) return
        cameraReleased=true
        try { recording?.stop() } catch(_:Exception) {}
        recording=null
        try { camera?.cameraControl?.cancelFocusAndMetering() } catch(_:Exception) {}
        camera=null
        capture=null
        videoCapture=null
        try { provider?.unbindAll() } catch(_:Exception) {}
        binding.faceOverlay.update(null,"")
        if(::binding.isInitialized){binding.shutter.text=if(mode==Mode.VIDEO)"REC" else "●";binding.status.text="ปล่อยกล้องแล้ว • $reason"}
    }

    override fun onDestroy(){
        releaseCameraResources("ปิดแอป")
        try { faceDetector.close() } catch(_:Exception) {}
        analysisExecutor.shutdownNow()
        provider=null
        super.onDestroy()
    }
    private fun stamp()=SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(System.currentTimeMillis())
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
