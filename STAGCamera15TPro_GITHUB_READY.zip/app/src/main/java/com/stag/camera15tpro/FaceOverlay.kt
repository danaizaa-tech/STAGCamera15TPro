package com.stag.camera15tpro

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class FaceOverlay @JvmOverloads constructor(c:Context,a:AttributeSet?=null):View(c,a){
    private var box:RectF?=null
    private var label=""
    private val stroke=Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.STROKE;strokeWidth=5f;color=Color.rgb(174,255,68) }
    private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize=36f;color=Color.WHITE;typeface=Typeface.DEFAULT_BOLD;setShadowLayer(6f,0f,2f,Color.BLACK) }
    fun update(rect:RectF?,name:String){box=rect;label=name;postInvalidate()}
    override fun onDraw(c:Canvas){super.onDraw(c);box?.let{c.drawRoundRect(it,24f,24f,stroke);c.drawText(label,it.left,it.top-12f,text)}}
}
