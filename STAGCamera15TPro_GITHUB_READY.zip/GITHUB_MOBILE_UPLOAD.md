# STAG Camera — GitHub Build from Mobile

## วิธีทำบนมือถือ

1. แตกไฟล์ ZIP นี้
2. สร้าง GitHub Repository ใหม่ เช่น `STAGCamera15TPro` (แนะนำ Private)
3. เข้า Repository > Add file > Upload files
4. อัปโหลด **ไฟล์และโฟลเดอร์ทั้งหมดภายในโฟลเดอร์โปรเจกต์นี้** ไปไว้ที่ root ของ Repository
   - ต้องเห็น `app/`, `.github/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`
   - ห้ามให้เกิดโครงสร้างซ้อนแบบ `STAGCamera15TPro/STAGCamera15TPro/app`
5. Commit changes
6. เข้าแท็บ **Actions**
7. เลือก workflow **Build APK**
8. ถ้า workflow ยังไม่ทำงาน ให้กด **Run workflow**
9. รอให้ `Build debug APK` ผ่าน
10. เข้า workflow run > Artifacts > ดาวน์โหลด `STAG-Camera-build-results`

## สิ่งที่ Workflow จะทำ
- Java 17
- Android SDK Platform 35
- Build Tools 35.0.0
- Gradle 8.9
- Validate Gradle project
- Run Android Lint
- Build `app-debug.apk`
- เก็บ APK และรายงาน Build เป็น Artifact

## ถ้า Build ไม่ผ่าน
ส่งข้อความ Error จากขั้นตอนที่เป็นสีแดงมาให้ผู้พัฒนาแก้ได้ทันที โดยเฉพาะบรรทัดแรกที่ขึ้น `e:` หรือ `FAILURE:`
