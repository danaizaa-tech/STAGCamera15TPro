# Camera Safety Cleanup v8

- `onStop()` stores the active mode and immediately releases camera resources.
- Active video recording is stopped before CameraX use cases are unbound.
- AF/AE focus metering is cancelled.
- `camera`, `capture`, and `videoCapture` references are cleared.
- `ProcessCameraProvider.unbindAll()` releases Preview/ImageCapture/VideoCapture/ImageAnalysis.
- Face tracking overlay is cleared.
- `onStart()` automatically reopens the camera and restores PHOTO, NIGHT, HDR, VIDEO, or STAGE mode.
- `onDestroy()` performs cleanup again safely, closes ML Kit and shuts down the analysis executor.
- An idempotent `cameraReleased` guard prevents duplicate release calls.

Expected behavior: pressing Home, switching apps, locking the screen, or opening Xiaomi Camera releases STAG's camera session automatically. Returning to STAG rebinds the previous mode.
