# STAG Multi-brand Concert Hub v6

This release combines public, generic concert-camera ideas into original STAG presets. It does not copy OEM code, trademarks, private AI models, LUTs, or hidden Camera HAL commands.

## Presets
- SMART: 5x, EV -1, Natural, performer tracking and Highlight Guard
- PERFORMER: 5x, EV -2, Classic, face AF/AE tracking
- SPOTLIGHT: 5x, EV -3, aggressive highlight protection
- FAR ZOOM: 10x request, EV -2, Classic; Camera HAL clamps unsupported zoom
- MOTION: 5x, EV -1, Vivid and tracking optimized for movement
- NIGHT: requests OEM Night Extension
- TRUE COLOR: Natural processing, conservative exposure
- 4K60: requests UHD 60 fps with tele priority and fallback
- AUDIO: toggles concert-audio intent in UI; real directional microphone selection/noise eraser is not exposed by generic CameraX and is not claimed as implemented

## Public feature inspirations
- Long-range telephoto, stage color and multi-frame dynamic range
- AI stage subject clarity, 4K stage video, dual-view concepts and audio cleanup
- Performer-outline preservation and ultra-night telephoto concepts
- Nightography, zoom stabilization and selectable microphone direction concepts

## Hardware limitations on Xiaomi 15T Pro
Presets control public zoom ratio, EV, OEM extensions, ML tracking, tone processing and recording requests. Physical lens choice, 10x reconstruction, proprietary denoise, directional microphone arrays and 4K60 stream combinations remain controlled by Xiaomi Camera HAL.
