# STAG Imaging Pipeline v3

## Included
- PHOTO, OEM NIGHT extension, OEM HDR extension
- Tone selection: NATURAL, CLASSIC, VIVID. These are STAG presets and do not claim to reproduce proprietary Leica profiles.
- UHD video with 60 fps request and hardware fallback
- Logical-camera automatic lens switching and 1x/5x/10x/20x controls
- Maximum-quality JPEG capture and OEM OIS/AF/AE/AWB when exposed by HAL

## Pipeline boundaries
OEM multi-frame fusion, Xiaomi Ultra Zoom reconstruction, proprietary Leica color matrices, private lens calibration tables and hidden vendor libraries cannot be legally or reliably bundled. The app requests public OEM Extensions and uses capability-based fallbacks.

## Next device-test phase
Capture Camera2 characteristics and sample images from the actual Xiaomi 15T Pro. Then tune STAG CLASSIC/VIVID matrices, sharpening and denoise values against RAW/JPEG test charts without copying proprietary assets.
