# Concert Night Mode v5

- Real-time face detection and tracking ID using bundled ML Kit model
- Largest visible face becomes stage subject target
- AF/AE metering follows the tracked face
- On-screen tracking rectangle
- Highlight Guard analyzes Y-plane pixels and automatically applies EV 0 to -4
- 5x telephoto priority with logical-camera lens switching
- Presets: AUTO, PERSON, LIGHT, VIDEO
- Night/HDR OEM extensions remain separately available

Limitations: face detection is not identity recognition. Camera HAL decides physical lens switching. During 4K60 video, ImageAnalysis may be unavailable in some stream combinations, so tracking overlay is currently optimized for still-photo Concert Night mode.
