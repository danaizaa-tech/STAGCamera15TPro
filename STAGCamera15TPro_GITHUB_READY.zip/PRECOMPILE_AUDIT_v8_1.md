# Pre-compile Audit v8.1

## Static checks completed
- Android project structure present
- Manifest and resource XML well formed
- ViewBinding references checked against layout IDs
- Kotlin braces and parentheses balanced
- Camera/audio permissions present
- CameraX, Extensions, Video, Camera2 interop and bundled ML Kit dependencies declared
- Java 17 and Kotlin JVM 17 explicitly configured
- GitHub workflow now installs Android SDK 35 and Build Tools 35.0.0, runs task validation, lint, then debug APK build
- `.gitignore` added

## ViewBinding
- Missing layout IDs referenced by Kotlin: ['ActivityMainBinding', 'isInitialized']
- Layout IDs not directly referenced in Kotlin: ['modeBar', 'toneBar', 'zoomBar']

## Items that require real compilation/device verification
1. CameraX 1.5.1 API compatibility for `ImageProxyTransformFactory`, `CoordinateTransform`, 60 fps requests, and Extensions on the resolved dependency set.
2. Xiaomi 15T Pro Camera HAL support for 5x physical lens switching, 10x/20x ratios, OEM Night/HDR extensions and UHD 60 fps stream combinations.
3. Memory pressure when decoding and re-encoding full-resolution JPEG as Bitmap. Large captures can temporarily consume significant RAM.
4. Video finalization when the app enters background. `Recording.stop()` is called before unbinding, but the real device must confirm files finalize reliably.
5. Face overlay transform accuracy must be tested with the actual sensor crop and PreviewView scale type.
6. Audio Focus remains a UI intent only; directional microphone and gain control are not implemented through generic CameraX.

## Build readiness
Static pre-compile validation passed. A successful APK cannot be claimed until Gradle, Android lint and Kotlin compilation complete in Android Studio or GitHub Actions.
